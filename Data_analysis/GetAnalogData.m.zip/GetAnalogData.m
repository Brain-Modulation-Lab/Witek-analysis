function [time, AnalogWaveforms, AnalogElectrodeIDs] = GetAnalogData(filename)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Get all 30kHz sampled data from .NS5 file
%
% Inputs:
%           filename - string containing path to NS5 file containing 30kHz data
% Outputs:
%           time - vector of sample timestamps in seconds
%           AnalogWaveforms - samples x channels matrix containing data
%           AnalogElectrodeIDs - vector containing numerical electrode IDs
%
%               Electrode IDs are numbered as follows:
%               Headstage inputs:
%                   Ripple NIP Port A - ElectrodeIDs 1:128
%                   Ripple NIP Port B - ElectrodeIDs 129:256
%                   Ripple NIP Port C - ElectrodeIDs 257:384
%                   Ripple NIP Port D - ElectrodeIDs 385:512
%               Analog I/O inputs:
%                   ElectrodeIDs 10241-10270
% 
% Witold Lipski 2013
% Adapted from RippleNeuroshareDemo1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ns_RESULT, hFile] = ns_OpenFile(filename);

% check to make sure the operation succeeded
if( strcmp(ns_RESULT, 'ns_OK') ~= 1 )
    disp(['ERROR: ns_OpenFile() returned ' ns_RESULT]);
    return;
end

% The file info structure "nsFileInfo" contains information about when the 
% recording was created, the timespan of the recording, timestamp 
% resolution in seconds, and the number of entities in the recording. 
[ns_RESULT, nsFileInfo] = ns_GetFileInfo(hFile);

% check to make sure the operation succeeded
if( strcmp(ns_RESULT, 'ns_OK') ~= 1 )
    disp(['ERROR: ns_OpenFile() returned ' ns_RESULT]);
    return;
end

% The entity inforamtion is read using ns_GetEntityInfo()
for i = 1:nsFileInfo.EntityCount
    [~, nsEntityInfo(i,1)] = ns_GetEntityInfo(hFile, i);
end

% Find Analog data, i.e. sampled time series
% As per the Neuroshare specification, The codes for the various types of 
% entities are as follows:
%   
%               Unknown entity                   0
%   
%               Event entity                     1
%   
%               Analog entity                    2
%   
%               Segment entity                   3
%   
%               Neural Event entity              4
%
% Another way to do this using nsFileInfo:
% AnalogEntityIDs  = find(strcmp({hFile.Entity(:).EntityType},'Analog'));
% Entity IDs from hFile.Entity and EntityInfo are treated as identical here.
%
AnalogEntityIDs  = find([nsEntityInfo.EntityType]==2);

% Find 30 kHz sampled data
% This is denoted by the hFile.FileInfo.Period property:
%
%   Period = 1	=> 30 kHz sampling 
%   Period = 30 => 1 kHz sampling
%
FileIndexes = [hFile.Entity(AnalogEntityIDs).FileType];
Periods = [hFile.FileInfo(FileIndexes).Period];
AnalogEntityIDs30kHz = AnalogEntityIDs(Periods==1);
if isempty(AnalogEntityIDs30kHz)
    disp('Could not find 30 kHz data.');
    return;
end

% Find Electrode IDs and other info about selected channels
AnalogElectrodeIDs  = [hFile.Entity(AnalogEntityIDs30kHz).ElectrodeID];
AnalogItemCounts  = [nsEntityInfo(AnalogEntityIDs30kHz).ItemCount];
AnalogEntityCount      = length(AnalogEntityIDs30kHz);
AnalogSampleReadStart  = 1;
AnalogSampleReadCount  = min(AnalogItemCounts);
AnalogSampleCounts     = zeros(AnalogEntityCount, 1);
AnalogWaveforms        = zeros(AnalogSampleReadCount, AnalogEntityCount);
% Get data
for i = 1:5 %AnalogEntityCount
    fprintf('Electrode %d\n', AnalogElectrodeIDs(i));
    [~, AnalogSampleCounts(i), AnalogWaveforms(:,i)] = ...
        ns_GetAnalogData(hFile, ...
                         AnalogEntityIDs30kHz(i), ...
                         AnalogSampleReadStart, ... 
                         AnalogSampleReadCount);
end
% Calculate sample times based on 30kHz sampling frequency
time = (1:AnalogSampleReadCount)/30000;